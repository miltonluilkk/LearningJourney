// class demonstration program

#include  <iostream>
using namespace std;

class	account {

private:	// restrict to this object (and friends) only
	long long	acc_num;
	string		holder;
	double		balance;
	
public:		// available everywhere
	void	deposit(double a);
	bool	withdraw(double a);
	void	print_details();
	// accessor functions
	long long	get_acc_num() { return acc_num; };
	double		get_balance() { return balance; };
	string		get_holder() { return holder; };
	// mutator functions
	void	set_acc_num(long long n) { acc_num = n; };
	void	set_balance(double b) { balance = b; };
	void	set_holder(string s) { holder = s; };
	// constructors
	account() { };	// allows object declarations without initialization
	account(long long n, string p, double b = 0.0) {
		acc_num = n; holder = p; balance = b;
		cout << "Message: new A/C [" << n << "] opened for ["
		     << p << "] with balance [" << b << "]\n";
	};
	// destructor
	~account() {
		if (balance != 0)
			cout << "Warning: account [" << acc_num
			     << "] closed with balance [" << balance
			     << "]\n";
	};
};

// account member function declarations

void	account::deposit(double a) {
	balance += a;
	cout << "Message: [" << a << "] deposited into A/C [" << acc_num
	     << "] new balance [" << balance << "]\n";
};

bool	account::withdraw(double a) {
	if (balance < a) {
		cout << "Warning: insufficient fund in A/C [" << acc_num
		     << "] for withdrawal of [" << a << "]\n";
		return false;
	} else {
		cout << "Message: [" << a << "] withdrawn from A/C ["
		     << acc_num << "] new balance [" << balance << "]\n";
		return true;
	}
};

void	account::print_details() {
	cout << "Account details:\n";
	cout << "Account number: [" << acc_num << "]\n";
	cout << "Account holder: [" << holder << "]\n";
	cout << "Account balance: [" << balance << "]\n";
};

int main() {

	account a1(123456789, "person 1", 1000.0);
	account a2;	// no initialization, first constructor used
	account a3(332211556, "person 2");

	a1.deposit(500.0);
	if ( ! a1.withdraw(2000.0)) cout << "Oops!\n";
	a1.print_details();

	a2.set_acc_num(132333435);
	a2.set_holder("another person");
	a2.set_balance(300.0);
	cout << "Second A/C [" << a2.get_acc_num() << "] opened for ["
	     << a2.get_holder() << "] with balance [" << a2.get_balance()
	     << "]\n";

	a3.print_details();
}
