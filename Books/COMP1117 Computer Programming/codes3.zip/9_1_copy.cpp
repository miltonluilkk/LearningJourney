//  Program to copy a source file to a destination file - command line version

#include <fstream>
#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

// setup source input stream
void setup_source(ifstream &in, char f[]) {
	in.open(f);
	if (in.fail()) {
		cout << "Cannot open \"" << f << "\".\n";
		exit(-1);
	}
}

// connect destination output stream
// return true if successful, false otherwise
bool connect_destination(ofstream &out, char f[]) {
	ifstream in;
	in.open(f);
	if ( ! in.fail() ) {	// destination file exists
		char c;
		in.close();
		cout << "Destination file \"" << f << "\" exists."
		     << "Type A to append, O to overwrite"
		     << ", and Q to quit: ";
		cin >> c;
		switch (c) {
		case 'a':
		case 'A':
			// open output for append
			out.open(f, ios::app);
			if (out.fail()) {
				cout << "Cannot open \"" << f
				     << "\" for append.\n";
				exit(-1);
			}
			return true;
		case 'o':
		case 'O':
			// same as new file
			break;
		case 'q':
		case 'Q':
			// don't copy, exit immediately
			exit(0);
		deafult:
			cout << "Unrecognized option.\n";
			exit(-1);
		}
	} else in.close();
	// open file for output from the beginning
	out.open(f);
	if (out.fail()) {
		cout << "Cannot open \"" << f << "\" for output.\n";
		exit(-1);
	}
	return true;
}

// copy from stream in to stream out
void copy(ifstream &in, ofstream &out) {
	char c;
	for ( ; ; ) {
		in.get(c);
		if (in.fail()) break;
		out.put(c);
	}
	if ( ! in.eof() ) cout << "I/O error while copying.\n";
}

int main(int argc, char *argv[]) {
	ifstream in;
	ofstream out;

	if (argc < 2) {
		cout << argv[0] <<": Too few arguments.\n";
		exit(-1);
	}
	if (strcmp(argv[1], argv[2]) == 0) {
		cout << argv[0]
			<<": source same as destination, nothing done!\n";
		exit(0);
	}
	setup_source(in, argv[1]);
	if ( ! connect_destination(out, argv[2]) ) {
		in.close();
		exit(-1);
	}
	copy(in, out);
	in.close();
	out.close();
	exit(0);
}
