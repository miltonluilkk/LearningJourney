// calendar printing program for years on or after 1800

#include  <iostream>
#include  <iomanip>
#include  <string>
using namespace std;

const	int	START_DAY_OF_WEEK = 3;
const	int	START_YEAR = 1800;

// get_date obtain month and year from user
bool	get_date(int &month, int &year) {
	cout << "Please input month (1-12) and year(2000- ) :";
	cin >> month >> year;
	if (month < 1 || month > 12) return false;
	if (year < 2000) return false;
	return true; 
}

// get_month_name return name of month, e.g., get_month(1) returns "January"
string	get_month_name(int month) {
	switch(month) {
	case 1:  return "           January";
	case 2:  return "           February";
	case 3:  return "            March";
	case 4:  return "            April";
	case 5:  return "             May";
	case 6:  return "             June";
	case 7:  return "             July";
	case 8:  return "            August";
	case 9:	 return "          September";
	case 10: return "           October";
	case 11: return "           November";
	case 12: return "           December";
	default: return " ";
	}
}

// is_leap_year return true if year is a leap year
bool	is_leap_year(int year) {
	return (year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0);
}

// get_days_in_month return number of days in a given month and year,
//   e.g., get_days_in_month(2, 1996) returns 29
int	get_days_in_month(int month, int year) {
	switch(month) {
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		return 31;
	case 4:
	case 6:
	case 9:
	case 11:
		return 30;
	case 2:
		return is_leap_year(year) ? 29 : 28;
	default:
		return 20;
	}
}

// get_days_in_year return days in a year
int	get_days_in_year(int year) {
	return is_leap_year(year) ? 366 : 365;
}

// get_day_of_week return day of week of first day of month in year
int	get_day_of_week(int month, int year) {
	int	t = 0;
	int	k;

	// determine days in years
	for (k = START_YEAR; k < year; k++ ) t += get_days_in_year(k);

	// add days in months
	for (k = 1; k < month; k++) t += get_days_in_month(k, year);

	return (START_DAY_OF_WEEK + t) % 7;
}

// print_month_body print main body of monthly calendar
void	print_month_body(int month, int year) {

	int	t = get_day_of_week(month, year);
	int	m = get_days_in_month(month, year);
	int	k;

	// position first day under the correct column
	for (k = t; k > 0; k--) cout << "     ";

	for (k = 1; k <= m; k++) {
		cout << setw(3) << k;
		if (++t == 7) {
			// end of week
			t = 0;
			cout << endl;
		} else cout << "  ";
	}
	if (t != 7) cout << endl;
}

// print_month print monthly calendar in table form, one row per week
void	print_month(int month, int year) {

	cout << get_month_name(month) << ' ' << year << endl;
	cout << "---------------------------------\n";
	cout << "Sun  Mon  Tue  Wed  Thu  Fri  Sat\n";
	cout << "---------------------------------\n";
	print_month_body(month, year);
	cout << "---------------------------------\n";
}

int main() {
	int	year, month;

	if (get_date(month, year)) {
		print_month(month, year);
	}
	else cout << "Error: month[" << month << "] and/or year ["
		  << year << "] unacceptable.\n";
}
