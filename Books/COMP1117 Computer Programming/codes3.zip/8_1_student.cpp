// program to demonstrate struct as return value
//   compile only, cannot execute
#include	<string>
using namespace std;
struct	person_name {
	string	first, middle, last;
};
struct	student {
	person_name	name;
	long long	uid;
	person_name	advisor;
};
// lookup up a student using binary search
// user need to double check the return value to determine whether or
//   not there is a match
student	lookup(student sdb[], int n, long long key) {
	student	dummy = {{"you", "and", "you"}, 0};
	int	m, u, v;
	u = 0;
	v = n - 1;
	while (u <= v) {
		m = (u + v) / 2;
		if (sdb[m].uid == key) return sdb[m];
		if (sdb[m].uid > key) v = m - 1;
		u = m + 1;
	}
	return dummy;
}
