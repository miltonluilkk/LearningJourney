//  program to demonstrate strings implemented using vectors of char
#include  <iostream>
#include  <vector>
using namespace std;

typedef	vector<char> alt_string;

// alt_strcat: strcat for alt_strings
void alt_strcat(alt_string &t, alt_string s) {
	for (unsigned k = 0; k < s.size(); k++) t.push_back(s[k]);
}

// alt_strcpy: strcpy for alt_strings
void alt_strcpy(alt_string &t, alt_string s) {
	t.resize(0);
	if (s.size() > 0) alt_strcat(t, s);
}

// alt_strcmp: strcmp for alt_strings
int	alt_strcmp(alt_string t, alt_string s) {
	unsigned	m = s.size();
	if (m > t.size() ) m = t.size();
	for (unsigned k = 0; k < m; k ++)
		if (t[k] > s[k]) return 1;
		else if (t[k] < s[k]) return -1;
	return 0;
}

// init_alt_string: initialize alt_string with given string literal
void	init_alt_string(alt_string &t, char s[]) {
	char	c;

	t.resize(0);
	for (int k = 0; c = s[k]; k++) t.push_back(c);
}

// cout_alt_string: print contents of alt_string to cout
void	cout_alt_string(alt_string s) {
	for (unsigned k = 0; k < s.size(); k++) cout << s[k];
}

int main() {
	alt_string	u, v;

	cout << "u [";
	cout_alt_string(u);
	cout << "]\n";
	cout << "v [";
	cout_alt_string(v);
	cout << "]\n";

	init_alt_string(u, "First string");
	init_alt_string(v, "Second string");
	cout << "u [" ;
	cout_alt_string(u);
	cout << "]\n";
	cout << "v [";
	cout_alt_string(v);
	cout << "]\n";

	alt_strcat(u, v);
	cout << "u [";
	cout_alt_string(u);
	cout << "]\n";
	cout << "v [";
	cout_alt_string(v);
	cout << "]\n";

	alt_strcpy(u, v);
	cout << "u [";
	cout_alt_string(u);
	cout << "]\n";
	cout <<"v [";
	cout_alt_string(v);
	cout << "]\n";

	cout << "alt_strcmp [" << alt_strcmp(u, v) << "]\n";

	u[5] = 'a';
	cout << "u [";
	cout_alt_string(u);
	cout << "]\n";
	cout << "v [";
	cout_alt_string(v);
	cout << "]\n";
	cout << "alt_strcmp [" << alt_strcmp(u, v) << "]\n";

        v[4] = 'a';
	cout << "u [";
	cout_alt_string(u);
	cout << "]\n";
	cout << "v [";
	cout_alt_string(v);
	cout << "]\n";
	cout << "alt_strcmp [" << alt_strcmp(u, v) << "]\n";
}
