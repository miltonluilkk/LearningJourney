// string demonstration program

#include <string>
#include <iostream>
using namespace std;

string	phrase, phrase2, name;
string	last_name = "Chan ";
string	first_name("Siu Man");

string	s = "abcdefgh";

string	print_bool(bool t) {
	return t? "true" : "false";
};

int main() {

	name = 'I';
	phrase = " like  ";
	phrase2 = phrase;

	cout << "name [" << name << "]\n";
	cout << "phrase [" << phrase << "]\n";
	cout << "phrase2 [" << phrase2 << "]\n";

	cout << "name + phrase [" << name + phrase << "]\n";
	cout << "I + phrase + HKU [" << 'I' + phrase + "HKU" << "]\n";

	cout << "phrase == phrase2 [" << print_bool(phrase == phrase2)
		<< "]\n";
	cout << "last_name > Cheng [" << print_bool(last_name > "Cheng")
		<< "]\n";

	{
		string	s("CS HKU");
		cout << s << endl;
		cout << s.length() << endl;
		cout << s[1] << endl;
		s[1] = 'E';
		cout << s << endl;
	};

	cout << "s.empty() [" << print_bool(s.empty()) << "]\n";
	cout << "s.find(ef) [" << s.find("ef") << "]\n";
	cout << "s.substr(2,4) [" << s.substr(2,4) << "]\n";
	cout << "s.insert(3,123) [" << s.insert(3,"123") << "]\n";
}
