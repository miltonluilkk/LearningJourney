// demonstration program on pointer arithmetic

#include  <iostream>
using namespace std;

double a[] = {1.1, 2.2, 3.3, 4.4, 5.5, 6.6};

void	print_ptr(double *a, int n) {
	cout << "print_ptr:";
	// a[i] is equivalent to a + i
	// a + i -> a + i * size of object pointed at by a
	for (int i = 0; i < n; i++) cout << ' ' << a[i];
	cout << endl;
}

void	print_array(double a[], int n) {
	cout << "print_array:";
	// *a delivers the value of the variable pointed at by a
	// a++ advances a to point at the next array element
	// a + 1 -> a + size of object pointed at by a
	for (int i = 0; i < n; i++) cout << ' ' << *a++;
	cout << endl;
}

void	print_update(double a[], int n) {
	cout << "print update:";
	// add 1 to a[i] after outputting its value
	for (int i = 0; i < n; i++) cout << ' ' << a[i]++;
	cout << endl;
}

int main() {
	print_array(a, 6);
	print_ptr(a, 6);
	print_update(a, 6);
	print_array(a, 6);
	print_ptr(a, 6);
}
