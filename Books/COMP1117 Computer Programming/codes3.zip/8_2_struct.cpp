// program to return the size of a struct
// the size of a struct MAY NOT be the sum of the sizes of its members!
// Lesson:  Don't assume anything about the layout of members in
//          the memory nor about the size of a struct

#include  <iostream>
using namespace std;

class	account {
	char	type;
	double	balance, interest_rate;
	int	term;
	bool	over_draft;
};

class tnuocca {
	bool	over_draft;
	char	type;
	int	term;
	double	balance, interest_rate;
};

account	a[10], b;

int main() {
	cout << "size of char is " << sizeof(char) << endl;
	cout << "size of int is " << sizeof(int) << endl;
	cout << "size of double is " << sizeof(double) << endl;
	cout << "size of bool is " << sizeof(bool) << endl;
	cout << "size of an account object is " << sizeof(b) << endl;
	cout << "size of 10 account objects is " << sizeof(a) << endl;
	cout << "size of a tnuocca object is " << sizeof(tnuocca) << endl;
}
