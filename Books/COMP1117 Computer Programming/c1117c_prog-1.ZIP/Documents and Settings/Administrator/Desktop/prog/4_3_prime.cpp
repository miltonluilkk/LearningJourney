//
//  prime.cpp  prints out prime factors of an integer
//
#include <iostream>
#include <cmath>
using namespace std;
int	n = 2;
bool valid_input() {
	cout << "Input an integer > 1 : "; 
	cin >> n;
	return n > 1;
}
void print_factors(int n) {
	int p = 2;
	do {
		if (n % p == 0) {
			cout << p;
			if ((n = n / p) <= 1) return;
			cout << " X ";
			continue;
		}
	} while (++p <= sqrt(n));
	cout << n;   // output last factor
}
int main() {
	if (valid_input()) {
		cout << n << " = ";
		print_factors(n);
		cout << endl;
	}
	else cout << "input [" << n
                  << "] invalid for program, a number > 1 is required\n";
}
