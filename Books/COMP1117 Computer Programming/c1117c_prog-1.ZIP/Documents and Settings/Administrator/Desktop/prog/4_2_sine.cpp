//
//  sine.cpp  floating-point rounding errors illustration
//
#include <iostream>
#include <cmath>
using namespace std;
int main() {
	double x, y;
        int k = -30;
	for (x = pow(2.0, -29.0); k++ < 0; x *= 2) {
		y = x - sin(x);
        	cout << x << "  " << x/y-sin(x)/y << endl;
	}
}
