//
//  sine.cpp  floating-point rounding illustration
//
#include <iostream>
#include <cmath>
using namespace std;
int main() {
	double x, y;
	int    k = -30;
	while (k++ < 0) {
		x = pow(2.0, (double)k);
		y = x - sin(x);
        	cout << x << "  " << x/y-sin(x)/y << endl;
	}
}
