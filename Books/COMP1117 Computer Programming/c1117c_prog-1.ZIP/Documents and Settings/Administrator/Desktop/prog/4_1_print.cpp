//
//  print.cpp  test printing of bool in true & false
//
#include <iostream>
#include <string>
using namespace std;
string print_bool(bool b) {
	return b?"true":"false";
}
int main() {
	cout << "true is " << print_bool(true);
	cout << " false is " << print_bool(false) << endl;
}
