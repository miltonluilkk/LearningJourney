//
//  prime.cpp  prints out prime factors of an integer (recursive version)
//
#include <iostream>
#include <cmath>
using namespace std;
int	n = 2;
bool valid_input() {
	cout << "Input an integer > 1 : "; 
	cin >> n;
	return n > 1;
}
void print_prime(int p, int n) {
	if (n > 1) // check for termination, note method works only for n > 1
		if (n % p == 0) {       // found a fector
			cout << p;
			if ((n = n / p) > 1) cout << " X ";
			print_prime(p, n);
		}
		else if (p < sqrt(n))   // check for termination again
			print_prime(p + 2, n);
		else cout << n;         // output last factor
}
void print_factors(int n) {
	while (n % 2 == 0) {
		cout << '2';
		if ((n = n / 2) <= 1) return;
		cout << " X ";
	}
	print_prime(3, n);
}
int main() {
	if (valid_input()) {
		cout << n << " = ";
		print_factors(n);
		cout << endl;
	}
	else cout << "input [" << n
                  << "] invalid for program, a number > 1 is required\n";
}
