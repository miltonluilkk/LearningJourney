//
//  const.cpp  prints inf and NaN
//
#include <iostream>
#include <cmath>
using namespace std;
int main() {
	double x = 0.0, y = 0.0, z = 1E50;
        cout << "z(1E50) is " << z << endl;
	cout << "0 / 0 is " << x/y << endl;
	cout << "e^1000 is " << exp(1000.0) << endl;
	cout << "-1/0.0 is " << -1/y << endl;
        cout << "sqrt(-1) is " << sqrt(-1.0) << endl;
}
