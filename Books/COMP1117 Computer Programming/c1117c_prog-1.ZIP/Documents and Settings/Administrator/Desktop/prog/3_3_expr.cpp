//
//  expr.cpp operand evaluation order illustration (correct version)
//
#include <iostream>
using namespace std;
int main() {
	int n=0, m, k;
	m = (n = 10) + (k = ++n);
	cout << "m = (n = 10) + (k = ++n); m is " << m << " n is " << n
		<< " k is " << k << endl;
	m = (n = 10) + (k = n++);
	cout << "m = (n = 10) + (k = n++); m is " << m << " n is " << n
		<< " k is " << k << endl;
	m = (k = ++n) + (n = 10);
	cout << "m = (k = ++n) + (n = 10); m is " << m << " n is " << n
		<< " k is " << k << endl;
	m = (k = n++) + (n = 10);
	cout << "m = (k = n++) + (n = 10); m is " << m << " n is " << n
		<< " k is " << k << endl;
}
