//
//  expr.cpp  operand evaluation order illustration
//
#include <iostream>
using namespace std;
int main() {
	int n=0, m;
	m = (n = 10) + (++n);
	cout << "m = (n = 10) + (++n); m is " << m << " n is " << n << endl;
	m = (n = 10) + (n++);
	cout << "m = (n = 10) + (n++); m is " << m << " n is " << n << endl;
	m = (++n) + (n = 10);
	cout << "m = (++n) + (n = 10); m is " << m << " n is " << n << endl;
	m = (n++) + (n = 10);
	cout << "m = (n++) + (n = 10); m is " << m << " n is " << n << endl;
}
