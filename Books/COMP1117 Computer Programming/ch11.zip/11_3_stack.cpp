// Stack class defined as a template class

#include  <cstddef>
#include  <iostream>
using namespace std;

template<class any> class stack {
private:
	struct	node {
		any*	contents;
		node*	next;
	};
	node*	top;
public:
	any*	pop() {
		if (top == NULL) return NULL;
		node	*t = top;
		any	*s = top->contents;
		top = top->next;
		delete t;
		return s;
	}
        void	push(any* a) {
		node	*t = new node;
		t->next = top;
		t->contents = a;
		top = t;
	}
	bool	empty() { return top == NULL; }
	stack() { top = NULL; }
	~stack() {
		node*	t;
		while (top != NULL) {
			t = top;
			top = top->next;
			delete t->contents;
			delete t;
		}
	}
};

int	main() {
	stack<string>	*str_stack = new stack<string>;
	string		*s = new string("first string");
	str_stack->push(s);
	s = new string("second string");
	str_stack->push(s);
	s = new string("third string");
	str_stack->push(s);
	s = new string("one final string");
	str_stack->push(s);
	cout << "start clearing stack\n";
	while ( ! str_stack->empty() ) {
		s = str_stack->pop();
		cout << *s << endl;
		delete s;
	}
}
