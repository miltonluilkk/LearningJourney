// Queue class defined as a template class

#include  <cstddef>
#include  <iostream>
using namespace std;

template<class any> class queue {
private:
	struct	node {
		any*	contents;
		node*	next;
	};
	node	*head, *tail;
public:
	any*	dequeue() {
		if (head == NULL) return NULL;
		node	*t = head;
		any	*s = head->contents;
		head = head->next;
		if (head == NULL) tail = NULL;	// last node removed
		delete t;
		return s;
	}
        void	enqueue(any* a) {
		node	*t = new node;
		t->next = NULL;
		t->contents = a;
		if (tail == NULL) head = t;	// first node added
		else tail->next = t;
		tail = t;
	}
	bool	empty() { return head == NULL; }
	queue() {
		head = NULL;
		tail = NULL;
	}
	~queue() {
		node*	t;
		while (head != NULL) {
			t = head;
			head = head->next;
			delete t->contents;
			delete t;
		}
	}
};

int	main() {
	queue<string>	*str_queue = new queue<string>;
	string		*s = new string("first string");
	str_queue->enqueue(s);
	s = new string("second string");
	str_queue->enqueue(s);
	s = new string("third string");
	str_queue->enqueue(s);
	s = new string("one final string");
	str_queue->enqueue(s);
	cout << "start clearing queue\n";
	while ( ! str_queue->empty() ) {
		s = str_queue->dequeue();
		cout << *s << endl;
		delete s;
	}
}
