// demonstration program for list operations

#include  <cstddef>	// contains definition of NULL
#include  <iostream>
using namespace std;

struct list_node {
	int		data;
	list_node	*next;
};

// print_list prints contents of entire list from beginning to end
void	print_list(list_node *list) {
	for (list_node *t = list; t != NULL; t = t->next) {
		cout << '\t' << t->data; 
	}
	cout << endl;
}

// search_list return pointer to node with matching key
list_node	*search_list(list_node *list, int key) {
	list_node	*t = list;
	for ( ; t != NULL; t = t->next)
		if (t->data == key) break;
	return t;
}

// insert_at_head insert new node as head of list
void	insert_at_head(list_node *&list, list_node *p) {
	p->next = list;
	list = p;
}

// insert_after_t insert new node after node pointed at by t
void	insert_after_t(list_node *t, list_node *p) {
	p->next = t->next;
	t->next = p;
}

// delete_at_head delete first node from list
//   return a pointer to the deleted node
list_node	*delete_at_head(list_node *&list) {
	list_node	*p = list;
	list = list->next;
	return p;
}

// delete_after_t delete node following node pointed at by t
//   return a pointer to the deleted node
list_node	*delete_after_t(list_node *t) {
	list_node	*p = t->next;
	t->next = p->next;
	return p;
}

// insert_in_order insert key into a sorted list
void	insert_in_order(list_node *&list, int key) {
	list_node	*t, *p = new list_node;
	p->data = key;
	if (list == NULL || list->data >= key) {
		insert_at_head(list, p);
		return;
	}
	for (t = list; t->next != NULL; t = t->next) {
		if (t->next->data >= key) break;
	}
	insert_after_t(t, p);
}

// delete_key return pointer to deleted node, NULL if not found
list_node	*delete_key(list_node *&list, int key) {
	if (list == NULL) return NULL;
	if (list->data == key) return delete_at_head(list);
	for (list_node *t = list; t->next != NULL; t = t->next) {
		if (t->next->data == key) return delete_after_t(t);
	}
	return NULL;
}

// delete_list free all nodes in list
void	delete_list(list_node *&list) {
	list_node	*t;
	for ( ; list != NULL; list = list->next) {
		t = list;
		cout << '[' << t->data << "] freed\n";
		delete t;
	}
}

int main() {
	list_node	*t, *list = NULL;

	insert_in_order(list, 100);
	insert_in_order(list, 25);
	insert_in_order(list, 33);
	insert_in_order(list, 3000);
	insert_in_order(list, 252);
	insert_in_order(list, 1);

	cout << "The initial list:";
	print_list(list);

	cout << "after deleting [33]:";
	t = delete_key(list, 33);
	delete t;
	print_list(list);

	cout << "after deleting [1]:";
	t = delete_key(list, 1);
	delete t;
	print_list(list);

	cout << "after deleting [3000]:";
	t = delete_key(list, 3000);
	delete t;
	print_list(list);

	cout << "after deleting [1000]:";
	if (delete_key(list, 1000) == NULL) cout << "\tOops";
	print_list(list);

	delete_list(list);
}
