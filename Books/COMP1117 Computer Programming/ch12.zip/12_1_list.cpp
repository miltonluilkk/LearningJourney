// stack and queue derived from list

#include  <cstddef>	// contains definition of NULL
#include  <iostream>
using namespace std;

template <class any> class	list {
private:
	struct node {
		any	*data;
		node	*next;
	};
	node	*head, *tail;
protected:
	// only accessible to derived classes
	//   cannot be used by clients of derived classes
	void	insert_at_head(any* t) {
		node	*n = new node;
		n->data = t;
		n->next = head;
		if (head == NULL) tail = n;
		head = n;
	}
	void	insert_at_tail(any* t) {
		node	*n = new node;
		n->data = t;
		n->next = NULL;
		if (head == NULL) head = n;
		else tail->next = n;
		tail = n;
	}
	any*	delete_at_head() {
		if (head == NULL) return NULL;
		node	*n = head;
		any	*t = head->data;
		head = head->next;
		if (head == NULL) tail = NULL;
		delete n;
		return t;
	}
public:
	bool	empty_list() { return head == NULL; }
	list() { head = tail = NULL; }
	~list() {
		node	*t;
		while (head != NULL) {
			t = head;
			head = head->next;
			delete t->data;
			delete t;
		}
	}
};

class str_stack : public list<string> {
public:
	void	push(string *t) { insert_at_head(t); }
	string*	pop() { return delete_at_head(); }
	bool	empty() { return empty_list(); }
	str_stack() { }		// default constructor of base called implicitly
	~str_stack() { }	// destructor of base called implicitly
};

class str_queue : public list<string> {
public:
	void	enqueue(string *t) { insert_at_tail(t); }
	string*	dequeue() { return delete_at_head(); }
	bool	empty() { return empty_list(); }
	str_queue() { }		// default constructor of base called implicitly
	~str_queue() { }	// destructor of base called implicitly
};


int main() {
	str_stack	*stk = new str_stack;
	string		*s = new string("first string");
	stk->push(s);
	s = new string("second string");
	stk->push(s);
	s = new string("third string");
	stk->push(s);
	s = new string("one final string");
	stk->push(s);
	cout << "start clearing stack\n";
	while ( ! stk->empty() ) {
		s = stk->pop();
		cout << *s << endl;
		delete s;
	}
	str_queue	*stq = new str_queue;
	s = new string("first string");
	stq->enqueue(s);
	s = new string("second string");
	stq->enqueue(s);
	s = new string("third string");
	stq->enqueue(s);
	s = new string("one final string");
	stq->enqueue(s);
	cout << "start clearing queue\n";
	while ( ! stq->empty() ) {
		s = stq->dequeue();
		cout << *s << endl;
		delete s;
	}
}
