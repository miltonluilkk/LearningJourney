#include  <iostream>
using namespace std;

class	a {
private:
	char	x;
public:
	virtual void	f() {
		cout << "Virtual " << x << endl;
	}
	void	g() {
		cout << "Non virtual " << x << endl;
	}
	a() { x = 'a'; }
	~a() {
		cout << x << " destroyed\n";
	}
};

class	b :	public a {
private:
	char	y;
public:
	virtual void	f() {
		cout << "Virtual " << y << endl;
	}
	void	g() {
		cout << "Non virtual " << y << endl;
	}
	b() { y = 'b'; }
	~b() {
		cout << y << " destroyed\n";
	}
};

class	c :	public b {
private:
	char	z;
public:
	virtual void	f() {
		cout << "Virtual " << z << endl;
	}
	void	g() {
		cout << "Non virtual " << z << endl;
	}
	c() { z = 'c'; }
	~c() {
		cout << z << " destroyed\n";
	}
};

int	main() {
	a	*p = new a;
	b	*q = new b;
	c	*r = new c;

	cout << "First set of calls:\n";
	p->f();
	p->g();
	q->f();
	q->g();
	r->f();
	r->g();

	cout << "Second set of calls:\n";
	p = q;
	p->f();
	p->g();
	q->f();
	q->g();
	r->f();
	r->g();

	cout << "Third set of calls:\n";
	p = r;
	q = r;
	p->f();
	p->g();
	q->f();
	q->g();
	r->f();
	r->g();
}
