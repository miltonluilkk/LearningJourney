//
//  bsearch.cpp  simple binary search program (recursive version 2)
//
#include <iostream>
using namespace std;
char c[] = "0123456789abcdefghijklmnopqrstuvwxyz";
int b_search(char c[], int n, char key) {
	int  m;
	if (n < 1) return -1;  			// check for termination
	m = (n - 1) / 2;                        // u = 0, v = n-1
	if (c[m] == key) return m;
	else if (c[m] > key)   			// continue in lower
		return b_search(c, m, key);   	// no adjustment needed
	else {                 			// continue in upper
		m++;
		int a = b_search(&c[m], n - m, key);
		if (a == -1) return -1;       	// not found
		return a + m; // convert return value from 0..n-m-1 to m..n-1
	}
}
int main() {
	char k;
	cout << "Input a letter to be searched: ";
	cin >> k;
	cout <<  k << " is in position " << b_search(c, sizeof(c), k)
	     << endl;
}
