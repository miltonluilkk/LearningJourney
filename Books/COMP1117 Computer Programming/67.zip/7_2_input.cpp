//  Text file input demonstration program

#include <fstream>	// source of ifstream
#include <iostream>	// source of cout
#include <cstdlib>	// source of exit
using namespace std;

ifstream  in_stream;
bool	b;
char	c;
double	d;
int	i;
string	s;

int main() {
	in_stream.open("infile.txt");	// not need to open cout
	if (in_stream.fail()) {
		cout << "Cannot open \"infile.txt\"\n";
		exit(-1);	// negative value indicates runtime error
	}
	in_stream >> c >> s >> i >> d >> b;
	cout << "c(" << c << ") s(" << s << ") i(" << i << ") d(" << d;
	cout << ") b(" << b << ")\n";
	in_stream.close();		// no need to close cout
	exit (0);		// normal termination
}
