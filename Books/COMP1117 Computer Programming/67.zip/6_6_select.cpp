//
//  select.cpp  selection sort -- one function version
//
#include <iostream>
using namespace std;

const int MAX = 100;
int a[100];

// input a sequence of int, terminate by non-numeric input
int get_data(int a[]) {
	int i = 0;
	cout << "Input a sequence of integers,"
	     << " terminate by a non-numeric input:" << endl;
	while (cin >> a[i]) {
		if (++i >= MAX) break;
	}
	return i;
}

// selection sort
void s_sort(int a[], int n) {
	int t, j;
	for (int k = n - 1; k > 0; k--) {
		t = k;
		for (j = k - 1; j >= 0; j--)	// a[t] is largest
			if (a[j] > a[t]) t = j;
		if (t != k) {	// largest not at end, need swapping
			j = a[t];
			a[t] = a[k];
			a[k] = j;
		}
	}
}

// print sorted array
void print_data(int a[], int n) {
	cout << "The sorted list:" << endl;
	for (int i = 0; i < n; i++)
		cout << a[i] << endl;
}

int main() {
	char n;
	if ((n = get_data(a)) > 0) {
		s_sort(a, n);
		print_data(a, n);
	}
}
