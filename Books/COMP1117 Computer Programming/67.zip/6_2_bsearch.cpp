//
//  bsearch.cpp  simple binary search program
//
#include <iostream>
using namespace std;
char c[] = "0123456789abcdefghijklmnopqrstuvwxyz";
int b_search(char c[], int n, char key) {
	int m, u, v;
	u = 0;       // u set at low end
	v = n - 1;   // v set at high end
	while (u <= v) {   // there are entries between u & v
		m = (u + v) / 2;
		if (c[m] == key) return m;
		else if (c[m] > key) v = m - 1;  // continue in lower
		else u = m + 1;                  // continue in upper
	}
	return -1;         // not found
}
int main() {
	char k;
	cout << "Input a letter to be searched: ";
	cin >> k;
	cout <<  k << " is in position " << b_search(c, sizeof(c), k) << endl;
}
