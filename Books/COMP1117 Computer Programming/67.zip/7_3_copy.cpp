//  Program to copy a source file to a destination file

#include <fstream>
#include <iostream>
#include <cstdlib>
using namespace std;

#define MAX_FILE_NAME 33

typedef char file_name[MAX_FILE_NAME];

// skip_line set marker to beginning of next line
// return false on input error; true on successful completion
bool skip_line(istream &in) {
	char c;
	do {
		in.get(c);
		if (in.fail()) return false;
	} while (c != '\n');
	return true;
}

// get file name from stream in
// return false if no input or input too long or I/O error
bool get_file_name(istream &in, file_name f) {
	char c;
	// skip leading space characters
	do in.get(c); while (c == ' ' || c == '\t');
	for (int i = 0; i < MAX_FILE_NAME; i++) {
		if (in.fail()) return false;	// input error, return false
		if (c != '\n') f[i] = c;
		else return i > 0;
		in.get(c);
	}
	skip_line(in);	// input too long, skip remaining characters in input
	return false;
}

// setup source input stream
// return true if successful, false otherwise
bool setup_source(ifstream &in, file_name f) {
	cout << "Please input source file name: ";
	if (get_file_name(cin, f)) {
		in.open(f);
		if (in.fail()) {
			cout << "Cannot open \"" << f << "\".\n";
			exit(-1);
		}
		return true;
	} else {
		cout << "Fail to obtain the source file name.\n";
		exit(-1);
	}
}

// equal_name checks whether or not given file names are identical
bool equal_name(file_name in, file_name out) {
	int i = 0;
	for ( ; i < MAX_FILE_NAME; i++) 
		if (in[i] != out[i]) return false;
	return true;
}

// get_valid_destination obtain destination file name
void get_valid_destination(file_name in, file_name out) {
	cout << "Please input destination file name: ";
	if (get_file_name(cin, out)) {
		if (equal_name(in, out)) {
			// do nothing if source == destination
			cout << "Warning! Source same as destination.\n";
			exit(0);
		}
		else return;
	} else {
		cout << "Fail to obtain the destination file name.\n";
		exit(-1);
	}
}

// connect destination output stream
// return true if successful, false otherwise
bool connect_destination(ofstream &out, file_name f) {
	ifstream in;
	in.open(f);
	if ( ! in.fail() ) {	// destination file exists
		char c;
		in.close();
		cout << "Destination file \"" << f << "\" exists."
		     << "Type A to append, O to overwrite"
		     << ", and Q to quit: ";
		cin >> c;
		switch (c) {
		case 'a':
		case 'A':
			// open output for append
			out.open(f, ios::app);
			if (out.fail()) {
				cout << "Cannot open \"" << f
				     << "\" for append.\n";
				exit(-1);
			}
			return true;
		case 'o':
		case 'O':
			// same as new file
			break;
		case 'q':
		case 'Q':
			// don't copy, exit immediately
			exit(0);
		deafult:
			cout << "Unrecognized option.\n";
			exit(-1);
		}
	} else in.close();
	// open file for output from the beginning
	out.open(f);
	if (out.fail()) {
		cout << "Cannot open \"" << f << "\" for output.\n";
		exit(-1);
	}
	return true;
}

// copy from stream in to stream out
void copy(ifstream &in, ofstream &out) {
	char c;
	for ( ; ; ) {
		in.get(c);
		if (in.fail()) break;
		out.put(c);
	}
	if ( ! in.eof() ) cout << "I/O error while copying.\n";
}

int main() {
	ifstream in;
	ofstream out;
	file_name in_file = {'\0'};	// entire array initialized to 0
	file_name out_file = {'\0'};	// - ditto -

	if ( ! setup_source(in, in_file) ) exit(-1);
	get_valid_destination(in_file, out_file);
	if ( ! connect_destination(out, out_file) ) {
		in.close();
		exit(-1);
	}
	copy(in, out);
	in.close();
	out.close();
	exit(0);
}
