//
//  min.cpp  finds the minimum of an array
//
#include <iostream>
using namespace std;
double x[] = { 4.1, 12.0, 7.3, 3.6, 5.9 };
double min(double x[], int n) {
	double min;

	cout << "Size of x in min: " << sizeof(x) << endl;
        min = x[0];
	for (int i = 1; i < n; i++)
		if (x[i] < min) min = x[i];
	return min;
}
int main() {
	cout << "Size of x in main: " << sizeof(x) << endl;
	cout << "min is " << min(x, 5) << endl;
}
