//
//  bsearch.cpp  simple binary search program (recursive version)
//
#include <iostream>
using namespace std;
char c[] = "0123456789abcdefghijklmnopqrstuvwxyz";
int b_search(char c[], int u, int v, char key) {
	int  m;
	if (u > v) return -1;  // check for termination
	m = (u + v) / 2;
	if (c[m] == key) return m;
	else if (c[m] > key)
		return b_search(c, u, m - 1, key); // continue in lower
	else
		return b_search(c, m + 1, v, key); // continue in upper
}
int main() {
	char k;
	cout << "Input a letter to be searched: ";
	cin >> k;
	cout <<  k << " is in position " << b_search(c, 0, sizeof(c) - 1, k)
	     << endl;
}
