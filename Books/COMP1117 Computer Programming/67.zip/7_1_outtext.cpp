//  Text file output demonstration program (with error checking)
#include <fstream>	// source of ofstream
#include <iostream>	// source of cout
#include <cstdlib>	// source of exit
using namespace std;
ofstream  out_stream;
int main() {
	out_stream.open("outfile.txt");	// not need to open cout
	if (out_stream.fail()) {
		cout << "Cannot open \"outfile.txt\"\n";
		exit(-1);	// negative value indicates runtime error
	}
	for (char c = 'a'; c <= 'z'; c++)
		out_stream << c << endl;
	out_stream.close();		// no need to close cout
	if (out_stream.fail()) {
		cout << "Cannot close \"outfile\"\n";
		exit(-2);	// a different value indicates a different error
	}
	exit (0);		// normal termination
}
