//
//  prime.cpp  prints out prime factors of an integer (improved version)
//
#include <iostream>
#include <cmath>
using namespace std;
int	n = 2;
bool valid_input() {
	cout << "Input an integer > 1 : "; 
	cin >> n;
	return n > 1;
}
void print_factors(int n) {
	int p = 3;
	while (n % 2 == 0) {
		cout << '2';
		if ((n = n / 2) <= 1) return;
		cout << " X ";
	}
	do {
		if (n % p == 0) {
			cout << p;
			if ((n = n / p) <= 1) return;
			cout << " X ";
		}
		else if ((p += 2) > sqrt(n)) break;
	} while (1);
	cout << n;        // output last factor
}
int main() {
	if (valid_input()) {
		cout << n << " = ";
		print_factors(n);
		cout << endl;
	}
	else cout << "input [" << n
                  << "] invalid for program, a number > 1 is required\n";
}
